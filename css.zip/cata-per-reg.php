<?php
require_once("cnx/swgc-mysql.php");
require_once("cls/cls-sistema.php");
$clSistema = new clSis();
session_start();
if($_POST)
{
	$eCodPerfil = $_POST['eCodPerfil'];
	mysql_query("DELETE FROM SisSeccionesPerfiles WHERE eCodPerfil = $eCodPerfil");
	foreach($_POST['tCodSeccion'] as $key => $tCodSeccion)
	{
		$tCodSeccion = "'".$tCodSeccion."'";
		mysql_query("INSERT INTO SisSeccionesPerfiles (eCodPerfil, tCodSeccion) VALUES ($eCodPerfil, $tCodSeccion)");
	}
}
?>
<div class="row">
	<div class="col-lg-12">
	<button type="button" class="btn btn-primary" onclick="guardar()"><i class="fa fa-save"></i> Guardar</button>
	</div>
</div>
<form action="?tCodSeccion=<?=$_GET['tCodSeccion']?>" method="post" id="datos">
	<input type="hidden" name="eAccion" id="eAccion" value="">
<div class="row">
                            <div class="col-lg-3">
                                <h2 class="title-1 m-b-25">Modificar permisos</h2>
                                <div class="table-responsive table--no-card m-b-40">
                                    <table class="table table-borderless table-striped table-earning">
                                        <tr>
											<td>Perfil</td>
											<td>
												<select name="eCodPerfil">
													<option value="">Seleccione</option>
													<?
														$select = "SELECT * FROM SisPerfiles ORDER BY tNombre ASC";
	  													$rsPerfiles = mysql_query($select);
	  													while($rPerfil = mysql_fetch_array($rsPerfiles))
														{
															?>
															<option value="<?=$rPerfil{'eCodPerfil'}?>"><?=utf8_decode($rPerfil{'tNombre'})?></option>
															<?
														}
													?>
												</select>
											</td>
										</tr>
                                    </table>
                                </div>
                            </div>
                            <div class="col-lg-9">
                                <h2 class="title-1 m-b-25">Secciones</h2>
                                <div class="table-responsive table--no-card m-b-40">
                                    <div class="au-card-inner">
                                        <div class="table-responsive">
                                            <table class="table table-borderless table-striped">
                                                <tbody>
													<?
													$select = "SELECT * FROM SisSecciones WHERE tCodPadre = 'inicio' ORDER BY ePosicion ASC";
													$rsSecciones = mysql_query($select);
													$b=0;
													while($rSeccion = mysql_fetch_array($rsSecciones))
													{
														?>
													<tr>
                                                        <td width="16"><input type="checkbox" name="tCodSeccion[<?=$b?>]" value="<?=$rSeccion{'tCodSeccion'}?>"></td>
                                                        <td colspan="2"><?=$rSeccion{'tTitulo'}?></td>
                                                    </tr>
													
													<?
													$b++;
														
													$select2 = "SELECT * FROM SisSecciones WHERE tCodPadre = '".$rSeccion{'tCodSeccion'}."' ORDER BY ePosicion ASC";
													$rsSecciones2 = mysql_query($select2);
													while($rSeccion2 = mysql_fetch_array($rsSecciones2))
													{
														?>
													<tr>
														<td></td>
                                                        <td width="16"><input type="checkbox" name="tCodSeccion[<?=$b?>]" value="<?=$rSeccion2{'tCodSeccion'}?>"></td>
                                                        <td><?=$rSeccion2{'tTitulo'}?></td>
                                                    </tr>
													<?
															$b++;
													}
													?>
													
													<?
													}
													?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
	
	</form>